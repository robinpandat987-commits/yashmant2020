"""CampusPulse model training package."""
