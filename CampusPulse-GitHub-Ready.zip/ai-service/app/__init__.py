"""CampusPulse AI Microservice package."""
